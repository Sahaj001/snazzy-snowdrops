from dataclasses import dataclass


@dataclass
class Pos:
    """Represents a position in the world with x and y coordinates."""

    x: int
    y: int
    z: int = 0  # Optional z-coordinate for 3D space

    def __add__(self, other: "Pos") -> "Pos":
        """Add two positions together."""
        return Pos(self.x + other.x, self.y + other.y)

    def __sub__(self, other: "Pos") -> "Pos":
        """Subtract one position from another."""
        return Pos(self.x - other.x, self.y - other.y)

    def __eq__(self, other: object) -> bool:
        """Check if two positions are equal."""
        if not isinstance(other, Pos):
            return NotImplemented
        return self.x == other.x and self.y == other.y
