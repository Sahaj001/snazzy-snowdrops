from __future__ import annotations
from typing import List
from models.draw_cmd import DrawCmd
from models.sprite import Sprite
from game.world import World
from engine.camera import Camera
from view.view_bridge import ViewBridge


class SpriteRegistry:
    """Stores and retrieves sprite data."""

    def __init__(self):
        self._sprites: dict[str, Sprite] = {}

    def get(self, sprite_id: str) -> Sprite:
        return self._sprites[sprite_id]

    def load_from_json(self, path: str) -> None:
        # implement loading sprite metadata from JSON
        pass


class RenderSystem:
    """Builds a draw queue and sends it to the view."""

    def __init__(
        self, sprites: SpriteRegistry, view_bridge: ViewBridge, camera: Camera
    ):
        self.sprites = sprites
        self.view_bridge = view_bridge
        self.camera = camera

    def build_draw_queue(self, _world: World, _camera: Camera) -> List[DrawCmd]:
        # Generate DrawCmd objects from world state
        return []

    def flush_to_view(self, cmds: List[DrawCmd]) -> None:
        self.view_bridge.draw(cmds)
