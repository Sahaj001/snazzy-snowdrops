from __future__ import annotations
from typing import List


class GameEvent:
    """Represents a game-wide event."""

    def __init__(self, event_type: str, payload: dict):
        self.type = event_type
        self.payload = payload


class EventBus:
    """A simple publish/subscribe queue."""

    def __init__(self):
        self._queue: List[GameEvent] = []

    def post(self, evt: GameEvent) -> None:
        self._queue.append(evt)

    def poll(self) -> List[GameEvent]:
        events = self._queue[:]
        self._queue.clear()
        return events
