from typing import Protocol
from models.position import Pos


class Object(Protocol):
    """Anything that has an ID and a position in the world."""

    id: str
    pos: Pos

    def destroy(self): ...


class Behaviour(Protocol):
    """Defines passability and interaction rules for entities."""

    @property
    def passable(self) -> bool: ...

    @property
    def interactable(self) -> bool: ...


class Interactable(Protocol):
    """Marks an entity as interactable by players or NPCs."""

    def interact(self, actor: "Entity") -> None: ...


class Living(Protocol):
    """Marks an entity as living with HP and damage handling."""

    hp: int

    def is_alive(self) -> bool: ...
    def take_damage(self, n: int) -> None: ...
