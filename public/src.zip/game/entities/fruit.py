from __future__ import annotations
from game.entities.entity import Entity
from engine.interfaces import Behaviour, Interactable, Pos


class Fruit(Entity, Interactable):
    def __init__(self, fruit_id: str, pos: Pos, behaviour: Behaviour, item_id: str):
        super().__init__(fruit_id, pos, behaviour)
        self.item_id = item_id

    def interact(self, actor: Entity) -> None:
        # Example: Add fruit to actor's inventory if available
        if hasattr(actor, "inventory"):
            actor.inventory.add(self.item_id, 1)
            print(f"{actor.id} picked up {self.item_id}")

    def update(self, *args, **kwargs) -> None:
        pass
