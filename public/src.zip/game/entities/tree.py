from __future__ import annotations
from game.entities.entity import Entity
from engine.interfaces import Behaviour, Interactable, Pos


class Tree(Entity, Interactable):
    def __init__(self, entity_id: str, pos: Pos, behaviour: Behaviour):
        super().__init__(entity_id, pos, behaviour)

    def interact(self, actor: Entity) -> None:
        print(f"{actor.id} interacts with tree {self.id}")

    def update(self, *args, **kwargs) -> None:
        # Trees may have seasonal changes or drop fruits
        pass
