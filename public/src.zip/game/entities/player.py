from game.entities.entity import Entity
from engine.interfaces import Living, Behaviour
from models.position import Pos
from game.inventory import Inventory


class Player(Entity, Living):
    def __init__(
        self, entity_id: str, pos: Pos, behaviour: Behaviour, speed: float = 1.0
    ):
        super().__init__(entity_id, pos, behaviour)
        self.inventory = Inventory()
        self.speed = speed
        self.hp = 100

    def move(self, dx: int, dy: int, world: "World") -> None:
        new_x = self.pos.x + dx
        new_y = self.pos.y + dy
        if world.is_passable(new_x, new_y):
            self.pos.x = new_x
            self.pos.y = new_y

    def update(self, *args, **kwargs) -> None:
        # Player-specific update logic can go here
        pass

    def is_alive(self) -> bool:
        return self.hp > 0

    def take_damage(self, n: int) -> None:
        self.hp = max(self.hp - n, 0)
