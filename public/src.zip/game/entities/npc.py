from __future__ import annotations
from game.entities.entity import Entity
from engine.interfaces import Behaviour, Living, Pos


class NPC(Entity, Living):
    def __init__(
        self, entity_id: str, pos: Pos, behaviour: Behaviour, ai_state: str = "idle"
    ):
        super().__init__(entity_id, pos, behaviour)
        self.ai_state = ai_state
        self.hp = 50

    def update(self, *args, **kwargs) -> None:
        # Basic AI logic can be implemented here
        pass

    def is_alive(self) -> bool:
        return self.hp > 0

    def take_damage(self, n: int) -> None:
        self.hp = max(self.hp - n, 0)
