from __future__ import annotations
from typing import List
from models.position import Pos
from game.entities.entity import Entity
from game.entities.player import Player


class Tile:
    """Represents a single tile in the world."""

    def __init__(self, sprite_id: str, passable: bool, z: int = 0):
        self.sprite_id = sprite_id
        self.passable = passable
        self.z = z


class TileMap:
    """Grid of tiles that makes up the world terrain."""

    def __init__(self, width: int, height: int, tile_size: int):
        self.width = width
        self.height = height
        self.tile_size = tile_size
        # 2D array: tiles[y][x]
        self.tiles: List[List[Tile | None]] = [
            [None for _ in range(width)] for _ in range(height)
        ]

    def get(self, x: int, y: int) -> Tile | None:
        """Get the tile at given coordinates."""
        if 0 <= x < self.width and 0 <= y < self.height:
            return self.tiles[y][x]
        return None

    def set(self, x: int, y: int, tile: Tile) -> None:
        """Set the tile at given coordinates."""
        if 0 <= x < self.width and 0 <= y < self.height:
            self.tiles[y][x] = tile

    def is_passable(self, x: int, y: int) -> bool:
        """Check if a tile can be walked on."""
        tile = self.get(x, y)
        return tile.passable if tile else False


class World:
    """The game world, containing all entities and the tile map."""

    def __init__(self, tiles: TileMap):
        self.players: List[Player] = []
        self.entities: List[Entity] = []
        self.tiles = tiles

    def find_near(self, pos: Pos, radius: int) -> List[Entity]:
        """Find all entities within `radius` of the given position."""
        result = []
        r2 = radius * radius
        for e in self.entities:
            dx = e.pos.x - pos.x
            dy = e.pos.y - pos.y
            if dx * dx + dy * dy <= r2:
                result.append(e)
        return result

    def is_passable(self, x: int, y: int) -> bool:
        """Check if a location is passable in the tile map."""
        return self.tiles.is_passable(x, y)

    def update(self, dt: float) -> None:
        """Update all entities in the world."""
        for e in self.entities:
            e.update(self, dt)

    def add_entity(self, entity: Entity) -> None:
        """Add an entity to the world."""
        self.entities.append(entity)

    def remove_entity(self, entity: Entity) -> None:
        """Remove an entity from the world."""
        if entity in self.entities:
            self.entities.remove(entity)

    def add_player(self, player: Player) -> None:
        """Add a player to the world."""
        self.players.append(player)
        self.add_entity(player)

    def remove_player(self, player: Player) -> None:
        """Remove a player from the world."""
        if player in self.players:
            self.players.remove(player)
            self.remove_entity(player)
