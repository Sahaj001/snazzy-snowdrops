from __future__ import annotations
from typing import List
from models.draw_cmd import DrawCmd
from engine.input_system import InputEvent


class ViewBridge:
    """Abstracts the JS ↔ Pyodide interface."""

    def __init__(self, canvas):
        self.canvas = canvas

    def draw(self, cmds: List[DrawCmd]) -> None:
        # This would call into JS to render
        pass

    def get_input_events(self) -> List[InputEvent]:
        # This would pull events from JS
        return []

    def load_assets(self, index_path: str) -> None:
        # This would load assets via JS
        pass
