class MenuScene:
    def start(self):
        print("Menu Scene started")

    def render(self):
        ctx = self.engine.ctx
        ctx.fillStyle = "red"
        ctx.fillRect(50, 50, 200, 150)
