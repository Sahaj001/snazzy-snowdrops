from ..engine.events import Event

class GameScene:
    def __init__(self, event_manager):
        self.event_manager = event_manager

    def start(self):
        print("Game scene started")
        self.event_manager.subscribe("keydown", self.on_key)

    def update(self):
        pass  # game logic here

    def render(self):
        pass  # draw to canvas here

    def on_key(self, event):
        print(f"Key pressed: {event.data['key']}")

