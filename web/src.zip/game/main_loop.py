def start():
    print("Game started!")
    # Here you'll set up event loop, scenes, etc.
