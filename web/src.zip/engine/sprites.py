from js import console, Image
from engine.canvas import Canvas

class TileMap:
    def __init__(self, canvas, tileset_src, tile_w, tile_h, map_data):
        self.canvas = canvas
        self.tile_width = tile_w
        self.tile_height = tile_h
        self.map_data = map_data
        self.tileset = Image.new()
        self.tileset.src = tileset_src
        self.loaded = False
        self.tileset.onload = self._on_load

    def _on_load(self, event):
        console.log("Tileset loaded")
        self.loaded = True

    def draw(self):
        if not self.loaded:
            return
        for row_idx, row in enumerate(self.map_data):
            for col_idx, tile_index in enumerate(row):
                # Calculate source tile position in tileset
                sx = (tile_index % (self.tileset.width // self.tile_width)) * self.tile_width
                sy = (tile_index // (self.tileset.width // self.tile_width)) * self.tile_height

                dx = col_idx * self.tile_width
                dy = row_idx * self.tile_height

                self.canvas.draw_sprite(self.tileset, sx, sy, self.tile_width, self.tile_height,
                                        dx, dy, self.tile_width, self.tile_height)

def start(js_canvas, js_ctx):
    console.log("Game started")

    canvas = Canvas(js_canvas, js_ctx)

    # Example tilemap (numbers are tile indexes)
    tilemap_data = [
        [0, 1, 2, 1, 0],
        [1, 2, 3, 2, 1],
        [2, 3, 0, 3, 2],
        [1, 2, 3, 2, 1],
        [0, 1, 2, 1, 0],
    ]

    # Provide your tileset image path here
    tileset_src = "/assets/tileset.png"
    tile_width = 32
    tile_height = 32

    tilemap = TileMap(canvas, tileset_src, tile_width, tile_height, tilemap_data)

    # Clear canvas and draw tilemap
    canvas.clear("#222")
    tilemap.draw()

    # Draw some shapes on top
    canvas.draw_rect(100, 100, 200, 150, "red")
    canvas.draw_circle(400, 300, 50, "blue")
    canvas.draw_text("Hello from Canvas class", 200, 500, "white", "24px Arial")
